import React from "react";
import { Box, Typography, Paper } from "@mui/material";

export default function Dashboard() {
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>

      <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
        <Paper sx={{ p: 2, width: 200, textAlign: "center" }}>Total Orders</Paper>
        <Paper sx={{ p: 2, width: 200, textAlign: "center" }}>Total Users</Paper>
        {/* <Paper sx={{ p: 2, width: 200, textAlign: "center" }}>Messages</Paper> */}
      </Box>
    </Box>
  );
}
