const db = require("../config/db");

// Fetch orders
exports.getOrders = (req, res) => {
  let query = "";
  let params = [];
  const { id, role } = req.query;

  // console.log("HERERERER");
  // console.log(req.query);
  
  // console.log(role);
  
  if (role === "admin") {
  // Admin: fetch all orders with customer name
  query = `
      SELECT o.id, o.user_id, u.username AS customerName, p.name AS productName,o.quantity,o.total_price,  o.status, o.created_at
      FROM orders o
      JOIN users u ON o.user_id = u.id
      JOIN products p ON o.product_id = p.id
      ORDER BY o.created_at DESC
    `;
  } else {
    // User: fetch only their own orders
    query = `
      SELECT o.id, o.user_id, u.username AS customerName, o.status, o.created_at
      FROM orders o
      JOIN users u ON o.user_id = u.id
      WHERE o.customerId = ?
      ORDER BY o.created_at DESC
    `;
    params.push(id);
  }

  db.query(query, params, (err, results) => {
    if (err) return res.status(500).json({ message: "Database error", err });
    res.json(results);
  });
};

// Create order (optional: only admin)
exports.createOrder = (req, res) => {
  if (req.user.type !== "admin") {
    return res.status(403).json({ message: "Only admin can create orders" });
  }

  const { customerId, status } = req.body;
  db.query(
    "INSERT INTO orders (customerId, status) VALUES (?, ?)",
    [customerId, status || "pending"],
    (err, result) => {
      if (err) return res.status(500).json({ message: "Database error", err });
      res.json({ message: "Order created", orderId: result.insertId });
    }
  );
};

// Update order status (admin only)
exports.updateOrderStatus = (req, res) => {
  // console.log("THTH");
  
  // console.log(req.body);
  
  if (req.body.user.role !== "admin") {
    return res.status(403).json({ message: "Only admin can update orders" });
  }

  const { id } = req.params;
  const { status } = req.body;

  db.query(
    "UPDATE orders SET status = ? WHERE id = ?",
    [status, id],
    (err, result) => {
      if (err) return res.status(500).json({ message: "Database error", err });
      if (result.affectedRows === 0)
        return res.status(404).json({ message: "Order not found" });
      res.json({ message: "Order updated successfully" });
    }
  );
};

// Delete order (admin only)
exports.deleteOrder = (req, res) => {
  console.log(req.query);
  
  if (req.query.role !== "admin") {
    return res.status(403).json({ message: "Only admin can delete orders" });
  }

  const { id } = req.params;

  db.query("DELETE FROM orders WHERE id = ?", [id], (err, result) => {
    if (err) return res.status(500).json({ message: "Database error", err });
    if (result.affectedRows === 0)
      return res.status(404).json({ message: "Order not found" });
    res.json({ message: "Order deleted successfully" });
  });
};
