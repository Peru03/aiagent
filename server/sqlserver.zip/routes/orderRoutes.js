const express = require("express");
const router = express.Router();
const { authMiddleware } = require("../middlewares/authMiddleware");
const {
  getOrders,
  deleteOrder,
  updateOrderStatus,
} = require("../controllers/orderController");

// Any authenticated user

router.get("/", getOrders);
router.put("/:id", updateOrderStatus);
router.delete("/:id", deleteOrder);

module.exports = router;

module.exports = router;
